//
//  Model.swift
//  FoodApp
//
//  Created by kireeti on 19/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation

class CategoriseData {
    var Items = [ItemData]()
    var name1 : String?
    init(dict:[String:Any]) {
        self.name1 = dict["name"] as? String
        let item = dict["items"] as! [[String : Any]]
        for i in item {
            let itemDetails = ItemData.init(dict: i)
            self.Items.append(itemDetails)
        }
        
    }
    
}

class ItemData {
    
    var name : String?
    var price : String?
    var img : String?
    var isVeg : Bool
    init(dict:[String: Any]) {
        self.name = dict["name"] as? String
        self.price = dict["price"] as? String
        self.img = dict["img"] as? String
        self.isVeg = (dict["isVeg"] != nil)
        
       
    }
}

