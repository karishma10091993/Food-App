//
//  ViewController.swift
//  FoodApp
//
//  Created by kireeti on 17/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import  Kingfisher
class ViewController: UIViewController {

    @IBOutlet var tableView: UITableView!
    var categireArray = NSMutableArray()
    var itemsArr = [ItemData]()
    var dataArray = [[String]]()
   
    var name1Data : [String] = []
    var imgData : [String] = []
    var priceData :[String] = []
    var items = [[String : AnyObject]]()
    override func viewDidLoad() {
        super.viewDidLoad()
      parseJson()
      
    }
    func parseJson(){
        let urlStr =  "https://demo1820943.mockable.io/restmenu"
        let url = URL.init(string: urlStr)
        let urlReq = URLRequest.init(url: url!)
        URLSession.shared.dataTask(with: urlReq) { (data, response, error) in
            guard let data = data else {return}
            do{
                let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
               // print("JSON Response--->",json)
               // let name =  json
                let catergorize = json["categories"] as! [[String : AnyObject]]
               // print(catergorize[0])
                for i in catergorize.indices {
                    let cate = catergorize[i]
                    let name1 = cate["name"] as! String
                    self.items = cate["items"] as! [[String : AnyObject]]

                for ite in self.items {
                   
                    let nameData : String = ItemData.init(dict: ite).name!
                    let priceData : String = ItemData.init(dict: ite).price!
                    let imgData : String = ItemData.init(dict: ite).img!
                    self.name1Data.append(nameData)
                    self.priceData.append(priceData)
                    self.imgData.append(imgData)
                   
                    }
                  
                }
                    
    
                DispatchQueue.main.async{
                    self.tableView.reloadData()
                }
            
               
                
                
                
        
            }catch{
                
            }
        }.resume()
    }
    
 
    
    
    
}
    

extension ViewController : UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.name1Data.count
    
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
      
        cell.nameLbl.text = self.name1Data[indexPath.row]
       cell.priceLbl.text = self.priceData[indexPath.row]
        if self.imgData[indexPath.row] .isEmpty{
            
        }else{
     cell.img.kf.setImage(with: URL.init(string: self.imgData[indexPath.row]))
        }
        return cell
      
       
    }
    
        

    }



    
    
    
    
    
    
    
    
    
    



