//
//  TableViewCell.swift
//  FoodApp
//
//  Created by kireeti on 21/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var img: UIImageView!
    @IBOutlet var priceLbl: UILabel!
    @IBOutlet var nameLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
