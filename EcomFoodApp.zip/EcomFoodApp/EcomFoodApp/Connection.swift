//
//  Connection.swift
//  EcomFoodApp
//
//  Created by kireeti on 02/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation

class Http {
     class func connection(API: String, httpMethod: HttpMethod,_ success: @escaping (_ json: Any?)-> Void, failure: @escaping (_ errorMessage: String) -> ()) -> Void {
        
        
        let url = URL.init(string: API)
        let urlReq = URLRequest.init(url: url!)
        let urlSession: URLSession = URLSession.init(configuration: .default)
        URLSession.shared.dataTask(with: urlReq) { (data, response, error) in
            do{
                let json =  try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                success(json)
                
            }catch{
                failure(error.localizedDescription)
            }
        }.resume()
    }
}

