//
//  Categories.swift
//  EcomFoodApp
//
//  Created by kireeti on 02/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation
enum HttpMethod : String {
    case GET, POST
}
class Categories {
    
    var name : String?
    var items = [Items]()
    
    init(dict : [String : Any]) {
        
        self.name = dict[ "name"] as? String
        let customItems = dict["items"] as! [[String : Any]]
        for food in  customItems {
           let foodItems = Items.init(dict: food)
            self.items.append(foodItems)
           
    }
    print("Items--->",self.items)
}
}

class Items {
    
    var name:String?
    var price: String?
    var img:String?
    var prod_Id: Int?
    var isVeg : Bool
    var must : Bool
    var image : String?
    
    init(dict: [String: Any]) {
        
        self.name = dict["name"] as? String
        self.price = dict["price"] as? String
        self.img = dict["img"] as? String
        self.prod_Id = dict["product_id"] as? Int
        self.isVeg = dict["isVeg"] as! Bool
        self.must = dict["must"] as! Bool
        self.img = dict["img"] as? String
        
    }
    
}
