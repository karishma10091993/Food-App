//
//  ViewController.swift
//  EcomFoodApp
//
//  Created by kireeti on 02/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import Kingfisher

class ViewController: UIViewController {
    var itemArray = [Categories]()
    @IBOutlet var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    

    

}
//CollectionView





extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.itemArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let  cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ItemsCell", for: indexPath) as! ItemsCell
        cell.itemData = self.itemArray[indexPath.row]
        return cell
    }
}


//CollectionViewCell

class ItemsCell : UICollectionViewCell{
    
    
    @IBOutlet var price: UILabel!
    @IBOutlet var recipeName: UILabel!
    @IBOutlet var img: UIImageView!
    
    var itemData: Categories? {
        
        didSet {
            if let itemData = itemData {
                
                self.recipeName.text = itemData.name
                if itemData.items.count > 0 {
                    self.price.text = " Rs. \(itemData.items[index].price)"
                }
               let index = 2
                if index >= 0 && index < itemData.items.count {
                    if let image = itemData.items[index].image {
                        img.kf.setImage(with: URL(string: image), placeholder: nil, options: [.transition(ImageTransition.fade(1)), .scaleFactor(1.0)], progressBlock: { (receivedSize, totalSize) in
                        }, completionHandler: { (image: Image?, error: NSError?, cacheType, urlImage: URL?) in
                        })
                    }
                } else{ return }
            }
        }
    }
}
