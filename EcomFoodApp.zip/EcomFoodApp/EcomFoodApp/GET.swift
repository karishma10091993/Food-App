//
//  GET.swift
//  EcomFoodApp
//
//  Created by kireeti on 02/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation

extension Items {
    func getProducts(_ success:@escaping (_ itemsArray: [Categories]) -> Void,failed: @escaping (_ errorMessage: String) -> Void){
        Http.connection(API: "https://demo1820943.mockable.io/restmenu", httpMethod: HttpMethod.GET, { (json) in
             var itemsArray = [Categories]()
            if let result = json as? [String: Any] {
               print("result---->", result)
                let items = result["categories"] as! [[String: Any]]
                for product in items {
                let prod = Categories.init(dict: product)
                    itemsArray.append(prod)
                }
                success(itemsArray)
            }
        }) { (error) in
            failed(error)
        }
    }
    
}
